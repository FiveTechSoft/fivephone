//
//  ___PROJECTNAMEASIDENTIFIER___ViewController.h
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ___PROJECTNAMEASIDENTIFIER___ViewController : UIViewController {

}

@end

